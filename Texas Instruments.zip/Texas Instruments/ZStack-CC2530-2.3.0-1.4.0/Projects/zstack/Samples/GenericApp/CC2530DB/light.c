/**
 * project�����ADC����
 * ʱ��  ��2012-7-9
 * ����  ��VigiLin from www.gec-edu.org
*/

#include "ioCC2530.h"
#include "stdio.h"
#include "math.h"
#include "hal_uart.h"

#define uint16 unsigned int
#define uint8 unsigned char

#define ADC_CHNN    0x05  //ѡ��ͨ��5

unsigned char s[8];//����һ�������СΪ8
void adc_Init(void);
uint16 get_adc(void);
void Get_val();
uint16 get_adc(void);


/********************************************************
 * @brief   ��ʱ
 *
 * @param   n - ��ʱ���� = n * 0.2 ms�� ��׼ȷ
********************************************************/
void Delay(uint16 n)
{
	uint16 i;
	for(i=0;i<n;i++);
	for(i=0;i<n;i++);
	for(i=0;i<n;i++);
	for(i=0;i<n;i++);
	for(i=0;i<n;i++);
}

/********************************************************
 * @brief   ��ʼ��UART
********************************************************/
void InitUART0(void)
{
	PERCFG = 0x00;		//λ��1 P0��
	P0SEL = 0x3c;		//P0��������
	
	P2DIR &= ~0XC0;         //P0������ΪUART0    
        U0CSR |= 0x80;   	//��������ΪUART��ʽ
        U0GCR |= 9;				
        U0BAUD |= 59;		//��������Ϊ19200

	UTX0IF = 1;            //UART0 TX�жϱ�־��ʼ��λ1  
        U0CSR |= 0X40;	        //��������
        IEN0 |= 0x84;	      //�����жϣ������ж�
}

/***********************************************
 * @brief   ��ʼ��ϵͳʱ�ӣ����ҽ�������Ϊ32M
***********************************************/
void InitClock(void)
{
    CLKCONCMD = 0x28;           //ʱ������ʱ���趨Ϊ1M Hz,  ϵͳʱ���趨Ϊ32 MHz 
    while(CLKCONSTA & 0x40);    //�Ⱦ����ȶ�
}

/********************************************************
 * @brief   UART��������
 *
 * @param   Data - ����ָ��
 *          len - ���ݳ���
********************************************************/
void UartTX_Send_String(char *Data,int len)
{
  int j;
  for(j=0;j<len;j++)
  {
    U0DBUF = *Data++;
    while(UTX0IF == 0);
    UTX0IF = 0;
  }
//     U0DBUF = '\n';        // ����
//    while(UTX0IF == 0);
//      UTX0IF = 0;
}

/********************************************************
 * @brief   ��ȡADC��ֵ
********************************************************/
static uint16 readAdc(uint8 channal)
{
          uint16 value ; 
          APCFG |= 1 << channal ; // ģ���ź�����
          ADCIF = 0 ;
         
          ADCCON3 = channal;          
          while ( !ADCIF ) ;  //�ȴ�ת�����
          
          value = ADCL ;
          value |= ((uint16) ADCH) << 8 ;
          
          return value; 
}

/****************************************************************
 * main����*/
//uint16 AvgValue = 0;
// char str[16];
//void ReadLightData(void)
//{	
//  // HalUARTWrite(0,"��ʼ����GETLUX\r\n",15);
//    char i;
//    
//    for (i = 0 ; i < 64 ; i++)
//    {
//      AvgValue += readAdc(ADC_CHNN);             
//      AvgValue >>= 1;
//    }
//    
//    sprintf(str, "%d\n",AvgValue);
//    HalUARTWrite(0,"LUX_ADC:",8);
//    HalUARTWrite(0,(unsigned char *)str,5);
//    HalUARTWrite(0,"\r\n",1);
//     
//     
//  /*//  sprintf(str, "%d\n", AvgValue);	
//   // UartTX_Send_String(str, 6);    // UART����ADC 
//     AvgValue = pow(10, ((log10(15) - log10(AvgValue/1000.0) + 0.6) / 0.6));//����ĵ���ֵ��λΪǧŷķ
//  sprintf(str, "%d\n",AvgValue);	
//    HalUARTWrite(0,(unsigned char *)str,5);
// 
//      AvgValue = pow(10, ((log10(15) - log10(AvgValue) + 0.6) / 0.6));//����ĵ���ֵ��λΪŷķ
//     // uint8 LUX[1];
//     // LUX[1]=AvgValue;
//     //  HalUARTWrite(0,LUX,1);
//   sprintf(str, "%d\n",AvgValue);	
//    HalUARTWrite(0,(unsigned char *)str,5);
//   //UartTX_Send_String(str, 6);    // UART����ADC */
//    Delay(50000);		// ��ʱ1s
//  
//}
#define HAL_ADC_DEC_064     0x00    /* Decimate by 64 : 8-bit resolution */
#define HAL_ADC_DEC_128     0x10    /* Decimate by 128 : 10-bit resolution */
#define HAL_ADC_DEC_256     0x20    /* Decimate by 256 : 12-bit resolution */
#define HAL_ADC_DEC_512     0x30    /* Decimate by 512 : 14-bit resolution */
#define HAL_ADC_DEC_BITS    0x30    /* Bits [5:4] */
#define HAL_ADC_CHANNEL_5          0x05   //�����ﶨ��˿ڣ�ʹ�ö˿ڣ�P0_5 ??? 
uint16 ReadLightData( void )

{
 
   uint16 reading = 0;

  P0DIR &= ~0x20;  // ����P0.5Ϊ���뷽ʽ

  asm("NOP");asm("NOP");

  
  /* Clear ADC interrupt flag */

  ADCIF = 0;

  
  ADCCON3 = (0x80 | HAL_ADC_DEC_064 | HAL_ADC_CHANNEL_5);

  
  /* Wait for the conversion to finish */

  while ( !ADCIF );

  
  asm("NOP");asm("NOP");

  
  /* Read the result */

  reading = ADCL;

  reading |= (int16) (ADCH << 8);

  reading >>= 8;

  ///////////////////////
  ///////////////////////

  ///////////////////////////
  return (50+(reading-70)*5);
}


///*************************//
//��ȡadcͨ��0����3�����ŵ�adc��ѹֵ
uint16 ReadADC0Data( void )
{
    char i;
    char str[16];
    uint16 AvgValue = 0;
    for (i = 0 ; i < 64 ; i++)
    {
      AvgValue += readAdc(0x00);             
      AvgValue >>= 1;
    }
    sprintf(str, "%d\n",AvgValue);
    HalUARTWrite(0,"ADC_0:",6);
    HalUARTWrite(0,(unsigned char *)str,5);
    HalUARTWrite(0,"\r\n",1);
    return (AvgValue);
}

//��ȡadcͨ��1����5�����ŵ�adc��ѹֵ
uint16 ReadADC1Data( void )
{
      char i;
    char str[16];
    uint16 AvgValue = 0;
    for (i = 0 ; i < 64 ; i++)
    {
      AvgValue += readAdc(0x01);             
      AvgValue >>= 1;
    }
    sprintf(str, "%d\n",AvgValue);
    HalUARTWrite(0,"ADC_1:",6);
    HalUARTWrite(0,(unsigned char *)str,5);
    HalUARTWrite(0,"\r\n",1);
    return (AvgValue);
}

//��ȡadcͨ��2����7�����ŵ�adc��ѹֵ
uint16 ReadADC2Data( void )
{
      char i;
    char str[16];
    uint16 AvgValue = 0;
    for (i = 0 ; i < 64 ; i++)
    {
      AvgValue += readAdc(0x02);             
      AvgValue >>= 1;
    }
    sprintf(str, "%d\n",AvgValue);
    HalUARTWrite(0,"ADC_2:",6);
    HalUARTWrite(0,(unsigned char *)str,5);
    HalUARTWrite(0,"\r\n",1);
    return (AvgValue);
}
