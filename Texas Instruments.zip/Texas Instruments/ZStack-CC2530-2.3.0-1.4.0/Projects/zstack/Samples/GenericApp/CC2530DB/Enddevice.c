#include "OSAL.h"
#include "AF.h"
#include "ZDApp.h"
#include "ZDObject.h"
#include "ZDProfile.h"
#include <string.h>
#include "Coordinator.h"
#include "DebugTrace.h"
#include "DHT11.h"
#include "light.h"
#include "hal_pwm.h"
#if !defined( WIN32 )
  #include "OnBoard.h"
#endif

/* HAL Ӳ�������(HAL) */
#include "hal_lcd.h"
#include "hal_led.h"
#include "hal_key.h"
#include "hal_uart.h"
#define SEND_DATA_EVENT  0x02

//0x39��Ӧ�������ϵ�P1_0,P1_3,P1_4,P1_5�ĸ�����
void Init_LED(void)
{
P1SEL&=~0x39;//���ܼĴ��� ��0Ϊ��ͨIO�ڣ�1Ϊ�ڶ�����--����
P1DIR|=0x39;//����Ĵ��� ��0Ϊ���� �� 1Ϊ���
P1&=~0x39;//���ĸ���Ϩ�𣬱���ֻ����һ����
}
//P1=0x01;//P1_0����  P1|=0x01;��1��  P1&=~0x01;��0��
const cId_t GenericApp_ClusterList[GENERICAPP_MAX_CLUSTERS] =
{
  GENERICAPP_CLUSTERID,
  GENERICAPP_TEMPCLUSTER,
  GENERICAPP_BROADCAST_CID
};

const SimpleDescriptionFormat_t GenericApp_SimpleDesc =
{
  GENERICAPP_ENDPOINT,              //  int Endpoint;
  GENERICAPP_PROFID,                //  uint16 AppProfId[2];
  GENERICAPP_DEVICEID,              //  uint16 AppDeviceId[2];
  GENERICAPP_DEVICE_VERSION,        //  int   AppDevVer:4;
  GENERICAPP_FLAGS,                 //  int   AppFlags:4;
  GENERICAPP_MAX_CLUSTERS,          //  byte  AppNumInClusters;
  (cId_t *)GenericApp_ClusterList,  //  byte *pAppInClusterList;
  GENERICAPP_MAX_CLUSTERS,          //  byte  AppNumInClusters;
  (cId_t *)GenericApp_ClusterList   //  byte *pAppInClusterList;
};

endPointDesc_t GenericApp_epDesc;


byte GenericApp_TaskID;   // Task ID for internal task/event processing
                          // This variable will be received when
                          // GenericApp_Init() is called.
devStates_t GenericApp_NwkState;


byte GenericApp_TransID;  // This is the unique message ID (counter)

afAddrType_t GenericApp_DstAddr;

//uint8 *my_strcat(uint8 *str1, uint8 *str2);
void GenericApp_MessageMSGCB( afIncomingMSGPacket_t *pckt );
void GenericApp_SendTheMessage( void );
//void To_string(uint8 *dest,char *src,uint8 length);
void GenericApp_Init( byte task_id )
{
  GenericApp_TaskID = task_id;
  GenericApp_NwkState = DEV_INIT;// Initialized - not connected to anything
  GenericApp_TransID = 0;
  
  //��Ӳ��ģ�鲿��
  // Device hardware initialization can be added here or in main() (Zmain.c).
  P0SEL &= ~0x10; //��ʼ��P0_4���¶�(DHT11)
  P0DIR |= 0x10;   //0:����  1�����
  P0_4 = 0;  
  // If the hardware is application specific - add it here.
  // If the hardware is other parts of the device add it in main().

  //�ж�����Ϊ��Э��������
  GenericApp_DstAddr.addrMode = (afAddrMode_t)Addr16Bit;//16λ����ģʽ
  GenericApp_DstAddr.endPoint =GENERICAPP_ENDPOINT;
  GenericApp_DstAddr.addr.shortAddr = 0x00;
 
  // Fill out the endpoint description.
  GenericApp_epDesc.endPoint = GENERICAPP_ENDPOINT;
  GenericApp_epDesc.task_id = &GenericApp_TaskID;
  GenericApp_epDesc.simpleDesc
            = (SimpleDescriptionFormat_t *)&GenericApp_SimpleDesc;
  GenericApp_epDesc.latencyReq = noLatencyReqs;

  // Register the endpoint description with the AF
  afRegister( &GenericApp_epDesc );
 
  //���ڵ�����
  halUARTCfg_t  uartConfig;
  //HalUARTCfg_t uartConfig;
  uartConfig.configured   =TRUE;
  uartConfig.baudRate     =HAL_UART_BR_115200;
  uartConfig.flowControl  =FALSE;
  uartConfig.callBackFunc =NULL;    
  HalUARTOpen(0,&uartConfig);
    Init_LED( );//P1|=0x01;��1��  P1&=~0x01;��0��
    
    myPWM_Init(2500);//19999>>8
}

//�¼���������
UINT16 GenericApp_ProcessEvent( byte task_id, UINT16 events )
{
  //HalUARTWrite(0,"Enddivce-�¼�����������ʼ",sizeof("Enddivce-�¼�����������ʼ"));
  afIncomingMSGPacket_t *MSGpkt;
  
  //*ϵͳ��Ϣ����*********1*********/ 
  if ( events & SYS_EVENT_MSG )
  {
    //ͨ����Ϣ���л��Ʊ�����Ϣ
    MSGpkt = (afIncomingMSGPacket_t *)osal_msg_receive( GenericApp_TaskID );
    while ( MSGpkt )
    {
      switch ( MSGpkt->hdr.event )
      {
       /* case ZDO_CB_MSG:
          GenericApp_ProcessZDOMsgs( (zdoIncomingMsg_t *)MSGpkt );
          break;
          
        case KEY_CHANGE:
          GenericApp_HandleKeys( ((keyChange_t *)MSGpkt)->state, ((keyChange_t *)MSGpkt)->keys );
          break;
        case AF_DATA_CONFIRM_CMD:
          // This message is received as a confirmation of a data packet sent.
          // The status is of ZStatus_t type [defined in ZComDef.h]
          // The message fields are defined in AF.h
          afDataConfirm = (afDataConfirm_t *)MSGpkt;
          sentEP = afDataConfirm->endpoint;
          sentStatus = afDataConfirm->hdr.status;
          sentTransID = afDataConfirm->transID;
          (void)sentEP;
          (void)sentTransID;

          // Action taken when confirmation is received.
          if ( sentStatus != ZSuccess )
          {
            // The data wasn't delivered -- Do something
          }
          break;*/

          //������Ϣ�¼�
        case AF_INCOMING_MSG_CMD:
          {  
            GenericApp_MessageMSGCB( MSGpkt ); }
          break;  

         //����״̬�ı��¼�
        case ZDO_STATE_CHANGE:
          
          GenericApp_NwkState = (devStates_t)(MSGpkt->hdr.status);
          if (GenericApp_NwkState == DEV_END_DEVICE) 
          { 
            HalLedSet(HAL_LED_2,HAL_LED_MODE_ON);//�������������
            osal_set_event(GenericApp_TaskID,SEND_DATA_EVENT);
             
          }
          break;

        default:
          break;
      }

      // Release the memory
      osal_msg_deallocate( (uint8 *)MSGpkt );//�ͷ��ڴ�
             
      // Next
      MSGpkt = (afIncomingMSGPacket_t *)osal_msg_receive( GenericApp_TaskID );
    } /*while ( MSGpkt )*/

    // return unprocessed events����δ�������¼�
     
  }/*if ( events & SYS_EVENT_MSG )*/

  //��ʪ�Ȳɼ�����
 if ( events & SEND_DATA_EVENT )
  {
    //Humidity_Measure(); //ʪ�ȵĻ�ȡ
    //���ܵ��ɼ���ʪ�Ȳ��������ݸ�Э����
    GenericApp_SendTheMessage();  //DHT11��ʪ�Ȳɼ����ڴ�ӡ�����߷��ͳ���
       // HalUARTWrite(0,"��ʼ����DHT11��ʪ�Ȳɼ����ڴ�ӡ�����߷��ͳ����¼�*",28);/*************/
    // Setup to send message again
    //��ʱ�����¼�
    osal_start_timerEx( GenericApp_TaskID,SEND_DATA_EVENT,3000 );
  return( events ^ SEND_DATA_EVENT );
  }
  return 0;
}

void GenericApp_SendTheMessage( void )
{  
    
    uint8  Tx_buff[14];//���͸�Э�����Ļ���
    uint8  Ad_buff[6];//���͸�Э�����Ļ���
    HalLedSet(HAL_LED_1,HAL_LED_MODE_ON);
    
    /*�նȲɼ��봦��*/
    char str1[7];
    uint16 LightValue;//�洢����ǿ����ֵ
       
    osal_memset(str1,0,7);     //�����ʼ��
 
    LightValue = ReadLightData();//�նȲɼ�
  

    osal_memcpy(str1, "BRI:", 4);
  
    str1[4] = LightValue / 100 + '0';
  //ת��Ϊascll��
    str1[5] = LightValue / 10%10 + '0';
  
    str1[6] = LightValue % 10 + '0';
          
    HalUARTWrite(0,str1,sizeof(str1));
    HalUARTWrite(0,"\r\n",sizeof("\r\n"));
    
     /*��ʪ�Ȳɼ��봦��*/   
    DHT11();   //��ʪ�Ȳɼ�         
    HalLedSet(HAL_LED_1,HAL_LED_MODE_ON);
    uint8 Temp[2];
    Temp[0] = wendu_shi+'0';  //ת��Ϊascll��
    Temp[1] = wendu_ge +'0';
    uint8 humidity[2];
    humidity[0] = shidu_shi+0x30;
    humidity[1] = shidu_ge+0x30;
    HalUARTWrite(0,"Temp:",5);    
    HalUARTWrite(0,Temp,2); 
    HalUARTWrite(0,"  Hum:",6);
    HalUARTWrite(0,humidity,2);
    

    
    //////////***************//////////
    uint16 adc0_Value;//�洢��0��ADC��ֵ
    char adc0[9];
    osal_memset(adc0,0,8);     //�����ʼ��
    adc0_Value=ReadADC0Data();  //��ȡͨ��0��ADCֵ
    osal_memcpy(adc0, "AD0:", 4);
    
    adc0[4] = adc0_Value / 10000 + '0';//ת��Ϊascll��
    adc0[5] = adc0_Value / 1000%10 + '0';
    adc0[6] = adc0_Value / 100%10 + '0';
    adc0[7] = adc0_Value / 10%10 + '0';
    adc0[8] = adc0_Value % 10 + '0';
    
    HalUARTWrite(0,adc0,sizeof(adc0));
    HalUARTWrite(0,"\r\n",sizeof("\r\n"));
    //////////////************/////////
      uint16 adc1_Value;//�洢��1��ADC��ֵ
    char adc1[9];
    osal_memset(adc1,0,8);     //�����ʼ��
    adc1_Value=ReadADC1Data();  //��ȡͨ��0��ADCֵ
    osal_memcpy(adc1, "AD1:", 4);
    
    adc1[4] = adc1_Value / 10000 + '0';//ת��Ϊascll��
    adc1[5] = adc1_Value / 1000%10 + '0';
    adc1[6] = adc1_Value / 100%10 + '0';
    adc1[7] = adc1_Value / 10%10 + '0';
    adc1[8] = adc1_Value % 10 + '0';
    
    HalUARTWrite(0,adc1,sizeof(adc1));
    HalUARTWrite(0,"\r\n",sizeof("\r\n"));
    //////////////************/////////
    uint16 adc2_Value;//�洢��0��ADC��ֵ
    char adc2[9];
    osal_memset(adc2,0,9);     //�����ʼ��
    adc2_Value=ReadADC2Data();  //��ȡͨ��0��ADCֵ
    osal_memcpy(adc2, "AD2:", 4);
    
    adc2[4] = adc2_Value / 10000 + '0';//ת��Ϊascll��
    adc2[5] = adc2_Value / 1000%10 + '0';
    adc2[6] = adc2_Value / 100%10 + '0';
    adc2[7] = adc2_Value / 10%10 + '0';
    adc2[8] = adc2_Value % 10 + '0';
    
    HalUARTWrite(0,adc2,sizeof(adc2));
    HalUARTWrite(0,"\r\n",sizeof("\r\n"));
 
   //////////////************/////////
    //////////////************/////////
    
        /*���ա���ʪ�ȴ���Tx_buffһ����*/
    Tx_buff[0]=Temp[0];
    Tx_buff[1]=Temp[1];
    Tx_buff[2]=humidity[0];
    Tx_buff[3]=humidity[1];
    Tx_buff[4]=str1[4];
    Tx_buff[5]=str1[5];
    Tx_buff[6]=str1[6];
    HalLedSet(HAL_LED_1,HAL_LED_MODE_OFF);
    Tx_buff[7]=adc0[4];
    Tx_buff[8]=adc0[5];
    Tx_buff[9]=adc1[4];
    Tx_buff[10]=adc1[5];
    Tx_buff[11]=adc2[4];
    Tx_buff[12]=adc2[5];    
  //  Tx_buff[13]='F';
    
    
    
    
    Ad_buff[0]=adc0[4];
    Ad_buff[1]=adc0[5];
    Ad_buff[2]=adc1[4];
    Ad_buff[3]=adc1[5];
    Ad_buff[4]=adc2[4];
    Ad_buff[5]=adc2[5];
    //����ն˴���
   // Tx_buff[13]='A';
    
    //�ж��ն˴���
   // Tx_buff[13]='B';
    
    //�����ն˴���
    Tx_buff[13]='C';
    
     /*���͸�Э����*/
    AF_DataRequest( &GenericApp_DstAddr, &GenericApp_epDesc,
                       GENERICAPP_CLUSTERID,  
                       14,
                       Tx_buff,
                       &GenericApp_TransID,
                       AF_DISCV_ROUTE, 
                       AF_DEFAULT_RADIUS ) ;
     
     /*AF_DataRequest( &GenericApp_DstAddr, &GenericApp_epDesc,
                       GENERICAPP_TEMPCLUSTER,
                       7,
                       Ad_buff,
                       &GenericApp_TransID,
                       AF_DISCV_ROUTE, 
                       AF_DEFAULT_RADIUS ) ;*/

}
/*
  uint8 lineFeed[2] = {0x0A,0x0D};        //�����������
  uint16 nwk;
  
  nwk = NLME_GetShortAddr();             //���������ַ ZDApp.c 856line
  To_string(rftx.myNWK,(uint8 *)&nwk,2); //uint8*4 uint16 = uint8*2
  To_string(rftx.myMAC,NLME_GetExtAddr(),8);
  
  
  
  HalUARTWrite(0,"parentMAC:",osal_strlen("parentMAC:"));
  HalUARTWrite(0,rftx.pMAC,16);
  HalUARTWrite(0,lineFeed,2);
 
}*/
 
  /*AF_DataRequest( &GenericApp_DstAddr, &GenericApp_epDesc,
                       GENERICAPP_CLUSTERID,
                       11,
                       (uint8 *)&rftx,
                       &GenericApp_TransID,
                       AF_DISCV_ROUTE, 
                       AF_DEFAULT_RADIUS ) ;*/


/*************************************************************************
*uint16 NLME_GetShortAddr(void)�����ķ���ֵΪ�ýڵ�16λ���������������ַ��
*�����Ҫ����������ַͨ��������PC�������ַ���ʽ���־���Ҫ�����ڶ�����
*����ת��Ϊ�ַ����ĺ���
***************************************************************************/
//����ֵת��Ϊ�ַ��������ض�Ӧ���ַ�����
/*void To_string(uint8 *dest,char *src,uint8 length)
{
    uint8 *xad;
    uint8 i=0;
    uint8 ch;
    xad = src + length-1;
    for(i=0;i<length;i++,xad--)
    {
        ch=(*xad >> 4) & 0x0F;//����ʮ��
        dest[i<<1] = ch + ((ch<10) ? '0' : '7');
        ch = *xad & 0x0F;
        dest[(i<<1) + 1] = ch + ((ch<10) ? '0' : '7');
    }
}
 
  
  char theMessageData[4] = "LED";

   AF_DataRequest( &GenericApp_DstAddr, &GenericApp_epDesc,
                       GENERICAPP_CLUSTERID,
                       (byte)osal_strlen( theMessageData ) + 1,
                       (byte *)&theMessageData,
                       &GenericApp_TransID,
                       AF_DISCV_ROUTE, AF_DEFAULT_RADIUS ) ;
  HalLedBlink(HAL_LED_2,0,50,500);*/

  //���յ�Э�������͹�������Ϣ������������
void GenericApp_MessageMSGCB(afIncomingMSGPacket_t *pkt )
{
  char buf[32];

  switch(pkt->clusterId)
  {
  /*case (GENERICAPP_CLUSTERID):
    osal_memcpy(buf,pkt -> cmd.Data,7);
     if(osal_memcmp(buf,"LED_ON",7))
     {
      HalLedSet(HAL_LED_2,HAL_LED_MODE_ON); 
     }
     if(osal_memcmp(buf,"LED_OFF",7))
     {
      HalLedSet(HAL_LED_2,HAL_LED_MODE_ON);
     }*/
  case GENERICAPP_BROADCAST_CID:
    osal_memcpy(buf,pkt -> cmd.Data,32);
///////////////////////1////////////////////////
   /* if(osal_memcmp(buf,"Drainage_machine1_ON",20))
     {
       HalUARTWrite(0,"111*",4);
       HalUARTWrite(0,buf,20);
       HalUARTWrite(0,"\r\n",sizeof("\r\n"));
       P1 |= 0x08;//��1�� 
      HalLedSet(HAL_LED_2,HAL_LED_MODE_ON); 
     } 
    if(osal_memcmp(buf,"Drainage_machine1_OFF",21))
     {
       HalUARTWrite(0,"110**",4);
       HalUARTWrite(0,buf,21);
       HalUARTWrite(0,"\r\n",sizeof("\r\n"));
      P1 &= ~0x08;//��0��
      HalLedSet(HAL_LED_3,HAL_LED_MODE_OFF);
     } 
    if(osal_memcmp(buf,"Water_level_alarm1_ON",21))
     {
       HalUARTWrite(0,"121*",4);
       HalUARTWrite(0,buf,21);
       HalUARTWrite(0,"\r\n",sizeof("\r\n"));
      HalLedSet(HAL_LED_2,HAL_LED_MODE_ON); 
      HalLedSet(HAL_LED_4,HAL_LED_MODE_ON);
      myPWM_Set(6.25,6.25,6.25);
     } 
    if(osal_memcmp(buf,"Water_level_alarm1_OFF",22))
     {
       HalUARTWrite(0,"120*",4);
       HalUARTWrite(0,buf,22);
       HalUARTWrite(0,"\r\n",sizeof("\r\n"));
      HalLedSet(HAL_LED_2,HAL_LED_MODE_ON); 
      HalLedSet(HAL_LED_4,HAL_LED_MODE_OFF);
      myPWM_Set(31.25,31.25,31.25);
     } 
    if(osal_memcmp(buf,"Rainfall_alarm1_ON",18))
     {
       HalUARTWrite(0,"131*",4);
       HalUARTWrite(0,buf,18);
       HalUARTWrite(0,"\r\n",sizeof("\r\n"));
       P1 &= ~0x10;//��0��
      HalLedSet(HAL_LED_2,HAL_LED_MODE_ON); 
     } 
    if(osal_memcmp(buf,"Rainfall_alarm1_OFF",19))
     {
       HalUARTWrite(0,"130*",4);
       HalUARTWrite(0,buf,19);
       HalUARTWrite(0,"\r\n",sizeof("\r\n"));
      P1 |= 0x10;//��1����  
      HalLedSet(HAL_LED_2,HAL_LED_MODE_ON); 
     } 
    if(osal_memcmp(buf,"Water_quality_alarm1_ON",23))
     {
       HalUARTWrite(0,"141*",4);
       HalUARTWrite(0,buf,23);
       HalUARTWrite(0,"\r\n",sizeof("\r\n"));
       P1 |= 0x20;//��1�� 
      HalLedSet(HAL_LED_2,HAL_LED_MODE_ON); 
     } 
    if(osal_memcmp(buf,"Water_quality_alarm1_OFF",24))
     {
       HalUARTWrite(0,"140*",4);
       HalUARTWrite(0,buf,24);
       HalUARTWrite(0,"\r\n",sizeof("\r\n"));
       P1 &= ~0x20;//��0��
      HalLedSet(HAL_LED_2,HAL_LED_MODE_ON); 
     } 

///////////////////////2////////////////////////
    if(osal_memcmp(buf,"Drainage_machine2_ON",20))
     {
       HalUARTWrite(0,buf,20);
       HalUARTWrite(0,"\r\n",sizeof("\r\n"));
       P1 |= 0x08;//��1�� 
      HalLedSet(HAL_LED_2,HAL_LED_MODE_ON); 
     } 
    if(osal_memcmp(buf,"Drainage_machine2_OFF",21))
     {
       HalUARTWrite(0,buf,21);
       HalUARTWrite(0,"\r\n",sizeof("\r\n"));
        P1 &= ~0x08;//��0��
      HalLedSet(HAL_LED_2,HAL_LED_MODE_ON); 
     } 
    if(osal_memcmp(buf,"Water_level_alarm2_ON",21))
     {
       HalUARTWrite(0,buf,21);
       HalUARTWrite(0,"\r\n",sizeof("\r\n"));
            myPWM_Set(6.25,6.25,6.25);
      HalLedSet(HAL_LED_2,HAL_LED_MODE_ON); 
     } 
    if(osal_memcmp(buf,"Water_level_alarm2_OFF",22))
     {
       HalUARTWrite(0,buf,22);
       HalUARTWrite(0,"\r\n",sizeof("\r\n"));
             myPWM_Set(31.25,31.25,31.25);
      HalLedSet(HAL_LED_2,HAL_LED_MODE_ON); 
     } 
    if(osal_memcmp(buf,"Rainfall_alarm2_ON",18))
     {
       HalUARTWrite(0,buf,18);
       HalUARTWrite(0,"\r\n",sizeof("\r\n"));
       P1 &= ~0x10;//��0��
      HalLedSet(HAL_LED_2,HAL_LED_MODE_ON); 
     } 
    if(osal_memcmp(buf,"Rainfall_alarm2_OFF",19))
     {
       HalUARTWrite(0,buf,19);
       HalUARTWrite(0,"\r\n",sizeof("\r\n"));
       P1 |= 0x10;//��1���� 
      HalLedSet(HAL_LED_2,HAL_LED_MODE_ON); 
     } 
    if(osal_memcmp(buf,"Water_quality_alarm2_ON",23))
     {
       HalUARTWrite(0,buf,23);
       HalUARTWrite(0,"\r\n",sizeof("\r\n"));
       P1 |= 0x20;//��1�� 
      HalLedSet(HAL_LED_2,HAL_LED_MODE_ON); 
     } 
    if(osal_memcmp(buf,"Water_quality_alarm2_OFF",24))
     {
       HalUARTWrite(0,buf,24);
       HalUARTWrite(0,"\r\n",sizeof("\r\n"));
       P1 &= ~0x20;//��0��
      HalLedSet(HAL_LED_2,HAL_LED_MODE_ON); 
     } 
*/
///////////////////////3////////////////////////
    if(osal_memcmp(buf,"Drainage_machine3_ON",20))
     {
       HalUARTWrite(0,buf,20);
       HalUARTWrite(0,"\r\n",sizeof("\r\n"));
       P1 |= 0x08;//��1�� 
      HalLedSet(HAL_LED_2,HAL_LED_MODE_ON); 
     } 
    if(osal_memcmp(buf,"Drainage_machine3_OFF",21))
     {
       HalUARTWrite(0,buf,21);
       HalUARTWrite(0,"\r\n",sizeof("\r\n"));
       P1 &= ~0x08;//��0��
      HalLedSet(HAL_LED_2,HAL_LED_MODE_ON); 
     } 
    if(osal_memcmp(buf,"Water_level_alarm3_ON",21))
     {
       HalUARTWrite(0,buf,21);
       HalUARTWrite(0,"\r\n",sizeof("\r\n"));
             myPWM_Set(6.25,6.25,6.25);
      HalLedSet(HAL_LED_2,HAL_LED_MODE_ON); 
     } 
    if(osal_memcmp(buf,"Water_level_alarm3_OFF",22))
     {
       HalUARTWrite(0,buf,22);
       HalUARTWrite(0,"\r\n",sizeof("\r\n"));
             myPWM_Set(31.25,31.25,31.25);
      HalLedSet(HAL_LED_2,HAL_LED_MODE_ON); 
     } 
    if(osal_memcmp(buf,"Rainfall_alarm3_ON",18))
     {
       HalUARTWrite(0,buf,18);
       HalUARTWrite(0,"\r\n",sizeof("\r\n"));
       P1 &= ~0x10;//��0��
      HalLedSet(HAL_LED_2,HAL_LED_MODE_ON); 
     } 
    if(osal_memcmp(buf,"Rainfall_alarm3_OFF",19))
     {
       HalUARTWrite(0,buf,19);
       HalUARTWrite(0,"\r\n",sizeof("\r\n"));
       P1 |= 0x10;//��1����
      HalLedSet(HAL_LED_2,HAL_LED_MODE_ON); 
     } 
    if(osal_memcmp(buf,"Water_quality_alarm3_ON",23))
     {
       HalUARTWrite(0,buf,23);
       HalUARTWrite(0,"\r\n",sizeof("\r\n"));
       P1 |= 0x20;//��1�� 
      HalLedSet(HAL_LED_2,HAL_LED_MODE_ON); 
     } 
    if(osal_memcmp(buf,"Water_quality_alarm3_OFF",24))
     {
       HalUARTWrite(0,buf,24);
       HalUARTWrite(0,"\r\n",sizeof("\r\n"));
       P1 &= ~0x20;//��0��
      HalLedSet(HAL_LED_2,HAL_LED_MODE_ON); 
     }     

    
    if(osal_memcmp(buf,"LED_ON",6))
     {
      HalLedSet(HAL_LED_2,HAL_LED_MODE_ON); 
     }
     if(osal_memcmp(buf,"LED_OFF",7))
     {
      HalLedSet(HAL_LED_2,HAL_LED_MODE_OFF);
     }
  }
}
