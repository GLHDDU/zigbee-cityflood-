//hal_pwm.h
#ifndef HAL_PWM_H
#define HAL_PWM_H
 
#ifdef __cplusplus
extern "C"
{
#endif
    
#include "hal_board.h"
 
void myPWM_Init(uint16 freq); // PWM初始化并设置频率
void myPWM_Set(uint8 duty1, uint8 duty2, uint8 duty3); // 传入3个通道的比较值，0~255有效
 
#ifdef __cplusplus
}
#endif
    
#endif
