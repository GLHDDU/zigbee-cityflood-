#ifndef __LIGHT_H__
#define __LIGHT_H__

//#define uchar unsigned char
//extern void Delay_ms(unsigned int xms); //��ʱ����
//extern void COM(void);         // ��ʪд��
//extern void DHT11(void);   //��ʪ��������
extern uint16 ReadLightData(void);
extern void Delay(uint16 n);
extern void InitUART0(void);
extern void InitClock(void);
extern void UartTX_Send_String(char *Data,int len);
extern uint16 readAdc(uint8 channal);
extern  uint16 AvgValue;

uint16 ReadADC0Data( void );
uint16 ReadADC1Data( void );
uint16 ReadADC2Data( void );
#endif
